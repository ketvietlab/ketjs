// SQLite adapter on node:sqlite. Zero dependencies - this ships inside Node.
import { DatabaseSync } from 'node:sqlite'
import { assertAdapter } from './adapter.ts'
import type { Adapter, FieldBase, Row } from '../types.ts'

// Binding rules belong to the adapter, not to the layers above it: SQLite has no
// boolean and no JSON, Postgres has both. Normalising here means every call path —
// query builder, changeset, raw run — is covered once.
const bind = (v: unknown): unknown => {
  if (typeof v === 'boolean') return v ? 1 : 0
  if (v === undefined) return null
  if (v !== null && typeof v === 'object') return JSON.stringify(v)
  return v
}

const SQL: Record<FieldBase, string> = {
  id: 'TEXT PRIMARY KEY', text: 'TEXT', int: 'INTEGER', float: 'REAL',
  bool: 'INTEGER', json: 'TEXT', datetime: 'TEXT', ref: 'TEXT',
}

export function sqliteAdapter(path = ':memory:'): Adapter {
  let db: DatabaseSync | null = null
  const need = (): DatabaseSync => { if (!db) throw new Error('adapter is not open()'); return db }

  const a: Adapter = {
    name: 'sqlite',
    async open() { db = new DatabaseSync(path); db.exec('PRAGMA journal_mode = WAL'); db.exec('PRAGMA foreign_keys = ON') },
    async close() { db?.close(); db = null },
    async exec(sql) { need().exec(sql) },
    async all(sql, params = []) { return need().prepare(sql).all(...(params.map(bind) as never[])) as Row[] },
    async run(sql, params = []) { const r = need().prepare(sql).run(...(params.map(bind) as never[])); return { changes: Number(r.changes) } },
    async tx(fn) {
      const d = need()
      d.exec('BEGIN')
      try { const r = await fn(a); d.exec('COMMIT'); return r }
      catch (e) { d.exec('ROLLBACK'); throw e }
    },
    quoteIdent(n) { return `"${String(n).replace(/"/g, '""')}"` },
    columnSql(c) { return SQL[c.base] ?? 'TEXT' },
    async introspect() {
      const tables: Record<string, Record<string, string>> = {}
      const names = need().prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'`).all() as Array<{ name: string }>
      for (const t of names) {
        tables[t.name] = {}
        const cols = need().prepare(`PRAGMA table_info(${a.quoteIdent(t.name)})`).all() as Array<{ name: string; type: string }>
        for (const c of cols) tables[t.name]![c.name] = c.type
      }
      return tables
    },
  }
  return assertAdapter(a)
}
